# DHN-Star PRICAI/LNAI Draft

Files:
- `main.tex`: anonymous Springer LNCS/LNAI-style long-paper draft.
- `references.bib`: initial bibliography with TODO notes for references that must be verified.
- `fig1_framework.png`: pipeline figure copied from the uploaded image.

Important:
1. Experimental results are placeholders by design.
2. Do not submit before replacing all `TBD`, `xx.x`, and TODOs with verified logs.
3. Verify all bibliography metadata against DBLP, CrossRef, PubMed, or publisher pages.
4. Remove any self-identifying repository paths, hardware names, acknowledgments, or author information before double-anonymous submission.